# JOSC Gallery — Cinematic Photo Gallery

Web galeri foto sinematik tanpa framework: HTML + CSS + JavaScript biasa,
ditambah Three.js, GSAP + ScrollTrigger, dan Lenis dari CDN.

## ▶️ Cara menjalankan (Termux)

```bash
cd josc-gallery
python -m http.server 8080
```

Lalu buka `http://localhost:8080` di browser HP.

> Jangan buka `index.html` langsung sebagai file (`file://`), karena JS-nya berbentuk
> ES module dan harus lewat server. Tombol "Run/Preview" di Acode juga bisa dipakai.
> Butuh koneksi internet untuk CDN (Three.js, GSAP, Lenis, Google Fonts).

## 🎬 Alur halaman

| # | Bagian | Foto | Transisi |
|---|--------|------|----------|
| 0 | Loading | Foto 5 (buku JOSC) | Buku jatuh → kamera zoom → sampul terbuka → halaman pertama membesar |
| 1 | Hero / Bio | Foto 4 (buku melayang) | Buku-buku 3D berputar mengelilingi buku bercahaya |
| 2 | Golden Hour | Foto 2 (koin di tangan) | Masuk ke cahaya, lalu keluar dari koin; sinar matahari berputar |
| 3 | Red Sun City | Foto 1 (matahari merah) | Matahari emas memenuhi layar, berubah merah, mendarat jadi matahari merah |
| 4 | Hanami | Foto 3 (sakura) | Kertas sobek jadi potongan + badai kelopak + burung + cahaya pink + blur-fokus |
| 5 | Penutup (opsional) | Foto 5 | Layar memutih, buku kembali; album + kontak + footer |

## 📁 Fungsi tiap file

```
index.html          Kerangka: loader, lapisan foto, menu, section, card, lightbox, link CDN
css/base.css        Warna, font, tombol, menu, kursor, efek kaca
css/loader.css      Tampilan buku 3D di loading
css/world.css       Latar foto + semua efek transisi (sinar, lingkaran, sobekan, dll)
css/sections.css    Hero bio, layout card galeri, kontak, footer, lightbox, versi HP
js/main.js          File utama, memanggil semua modul lain
js/config.js        Deteksi HP/desktop + batas performa
js/utils.js         Fungsi bantu (split text, preload gambar, jam WIB)
js/smooth.js        Lenis smooth scroll + ScrollTrigger
js/stage.js         Posisi foto & titik penting (koin, matahari merah) di layar
js/loader.js        Animasi loading buku
js/intro.js         Animasi masuk hero
js/hero3d.js        Scene Three.js buku berputar
js/petals.js        Kelopak sakura (canvas 2D)
js/scroll.js        Semua transisi saat scroll
js/ui.js            Kursor, tombol magnet, tilt card, lightbox, menu HP
assets/img/         Foto utama (webp) + potongan foto untuk card
```

## ✏️ Yang sering diubah

- **Teks bio:** `index.html` → `<section class="hero">`
- **Foto galeri:** ganti file di `assets/img/cards/`, lalu sesuaikan `alt`, `width`, `height` di `index.html`
- **Warna:** `css/base.css` → bagian `:root`
- **Panjang/kecepatan transisi:** tinggi `.transit--1` … `.transit--4` di `css/sections.css`
- **Performa HP:** angka di `js/config.js` (jumlah buku, kelopak, FPS)
- **Hapus bagian penutup:** hapus blok `#t4` dan `#album` di `index.html`

## ⚡ Catatan performa

- Satu loop animasi saja (GSAP ticker) untuk Lenis, Three.js, dan kelopak
- Three.js hanya render saat hero terlihat; FPS dibatasi 30 di HP
- Resolusi canvas dibatasi (DPR cap); blur hanya aktif di desktop
- Menghormati pengaturan "reduce motion" di HP
